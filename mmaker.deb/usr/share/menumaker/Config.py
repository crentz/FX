pkgHome		= "http://menumaker.sourceforge.net"
pkgName		= "MenuMaker"
pkgVer		= "0.99.12"

author		= "Oleg A. Khlybov"
email		= "fougas@mail.ru"
copyright	= "(c) 2002-2020"
